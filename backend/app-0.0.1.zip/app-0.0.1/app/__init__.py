def hello():
	return 'Hello world!'
def add(x,y):
	return x+y